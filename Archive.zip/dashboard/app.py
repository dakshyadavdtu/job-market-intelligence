from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

DATA_GOLD_ROOT = Path("data/gold/skill_demand_monthly")
HEALTH_FILE = Path("data/health/latest_ingest.json")

st.set_page_config(page_title="JMI Dashboard", layout="wide")
st.title("Job Market Intelligence (MVP)")

col1, col2 = st.columns(2)
with col1:
    st.subheader("Pipeline Freshness")
    if HEALTH_FILE.exists():
        st.json(pd.read_json(HEALTH_FILE, typ="series").to_dict())
    else:
        st.info("No health metadata found yet. Run ingest first.")

with col2:
    st.subheader("Top Skills")
    parquet_files = sorted(DATA_GOLD_ROOT.glob("ingest_month=*/part-*.parquet"))
    if parquet_files:
        latest = parquet_files[-1]
        df = pd.read_parquet(latest)
        st.caption(f"Using: {latest}")
        st.dataframe(df.head(20), use_container_width=True)
        st.bar_chart(df.set_index("skill")["job_count"].head(15))
    else:
        st.info("No Gold dataset yet. Run silver and gold transforms.")
