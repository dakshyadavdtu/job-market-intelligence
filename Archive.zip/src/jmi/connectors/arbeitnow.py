from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from typing import Any

import requests

ARBEITNOW_URL = "https://www.arbeitnow.com/api/job-board-api"


def fetch_live_jobs(timeout_sec: int = 20) -> list[dict[str, Any]]:
    response = requests.get(ARBEITNOW_URL, timeout=timeout_sec)
    response.raise_for_status()
    payload = response.json()
    return payload.get("data", [])


def normalize_skill_tokens(raw_tags: list[str] | None) -> list[str]:
    if not raw_tags:
        return []
    return sorted({tag.strip().lower() for tag in raw_tags if tag and tag.strip()})


def stable_job_id(source: str, title: str, company: str, location: str, published_at: str) -> str:
    base = "|".join(
        [
            source.strip().lower(),
            title.strip().lower(),
            company.strip().lower(),
            location.strip().lower(),
            published_at.strip().lower(),
        ]
    )
    return sha256(base.encode("utf-8")).hexdigest()


def to_bronze_record(raw: dict[str, Any]) -> dict[str, Any]:
    ingested_at = datetime.now(timezone.utc).isoformat()
    title = raw.get("title", "") or ""
    company = raw.get("company_name", "") or ""
    location = raw.get("location", "") or ""
    published_at = str(raw.get("created_at", "") or "")
    job_id = stable_job_id("arbeitnow", title, company, location, published_at)

    return {
        "source": "arbeitnow",
        "schema_version": "v1",
        "job_id": job_id,
        "ingested_at": ingested_at,
        "raw_payload": raw,
    }
