from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class QualityReport:
    row_count: int
    null_title: int
    null_company: int
    duplicate_job_id: int


def run_silver_checks(df: pd.DataFrame) -> QualityReport:
    return QualityReport(
        row_count=len(df),
        null_title=int(df["title"].isna().sum()) if "title" in df else 0,
        null_company=int(df["company_name"].isna().sum()) if "company_name" in df else 0,
        duplicate_job_id=int(df["job_id"].duplicated().sum()) if "job_id" in df else 0,
    )
