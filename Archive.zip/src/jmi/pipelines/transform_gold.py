from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.jmi.config import AppConfig
from src.jmi.utils.io import write_parquet


def _latest_silver_file(cfg: AppConfig) -> Path:
    files = sorted(cfg.silver_root.glob("jobs/ingest_date=*/part-*.parquet"), key=lambda p: p.stat().st_mtime)
    if not files:
        raise FileNotFoundError("No silver files found. Run silver transform first.")
    return files[-1]


def run() -> dict:
    cfg = AppConfig()
    silver_file = _latest_silver_file(cfg)
    df = pd.read_parquet(silver_file)
    if df.empty:
        raise RuntimeError("Silver dataset is empty.")

    # Explode skill arrays for dashboard-friendly aggregates.
    skill_df = df[["job_id", "skills"]].explode("skills").dropna(subset=["skills"])
    skill_agg = (
        skill_df.groupby("skills", as_index=False)["job_id"]
        .nunique()
        .rename(columns={"skills": "skill", "job_id": "job_count"})
        .sort_values("job_count", ascending=False)
    )

    ingest_month = datetime.now(timezone.utc).strftime("%Y-%m")
    out_path = cfg.gold_root / "skill_demand_monthly" / f"ingest_month={ingest_month}" / "part-00001.parquet"
    write_parquet(out_path, skill_agg)

    payload = {
        "stage": "gold",
        "ingest_month": ingest_month,
        "row_count": int(len(skill_agg)),
        "source_silver_file": str(silver_file),
        "output_file": str(out_path),
    }
    (cfg.quality_root / f"gold_quality_{ingest_month}.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    return payload


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
