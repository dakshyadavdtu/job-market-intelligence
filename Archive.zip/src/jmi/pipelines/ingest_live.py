from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from src.jmi.config import AppConfig, new_run_id
from src.jmi.connectors.arbeitnow import fetch_live_jobs, to_bronze_record
from src.jmi.utils.io import ensure_dir, write_jsonl_gz


def run() -> dict:
    cfg = AppConfig()
    run_id = new_run_id()
    ingest_date = datetime.now(timezone.utc).date().isoformat()

    raw_jobs = fetch_live_jobs()
    bronze_records = [to_bronze_record(job) for job in raw_jobs]

    out_path = (
        cfg.bronze_root
        / f"source={cfg.source_name}"
        / f"ingest_date={ingest_date}"
        / f"run_id={run_id}"
        / "raw.jsonl.gz"
    )
    write_jsonl_gz(out_path, bronze_records)

    health_path = cfg.health_root / "latest_ingest.json"
    ensure_dir(health_path.parent)
    health_path.write_text(
        json.dumps(
            {
                "source": cfg.source_name,
                "run_id": run_id,
                "ingest_date": ingest_date,
                "record_count": len(bronze_records),
                "bronze_path": str(out_path),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"run_id": run_id, "record_count": len(bronze_records), "bronze_path": str(out_path)}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
