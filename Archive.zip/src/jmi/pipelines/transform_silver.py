from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.jmi.config import AppConfig
from src.jmi.connectors.arbeitnow import normalize_skill_tokens
from src.jmi.utils.io import read_jsonl_gz, write_parquet
from src.jmi.utils.quality import run_silver_checks


def _latest_bronze_file(cfg: AppConfig) -> Path:
    files = sorted(
        cfg.bronze_root.glob(f"source={cfg.source_name}/ingest_date=*/run_id=*/raw.jsonl.gz"),
        key=lambda p: p.stat().st_mtime,
    )
    if not files:
        raise FileNotFoundError("No bronze files found. Run ingest first.")
    return files[-1]


def run() -> dict:
    cfg = AppConfig()
    bronze_file = _latest_bronze_file(cfg)
    bronze_rows = read_jsonl_gz(bronze_file)
    if not bronze_rows:
        raise RuntimeError("Bronze file is empty.")

    flattened: list[dict] = []
    for row in bronze_rows:
        payload = row.get("raw_payload", {})
        title = (payload.get("title") or "").strip()
        company = (payload.get("company_name") or "").strip()
        location = (payload.get("location") or "").strip()
        remote = bool(payload.get("remote", False))
        url = payload.get("url", "")
        created = str(payload.get("created_at", "") or "")
        skills = normalize_skill_tokens(payload.get("tags"))

        flattened.append(
            {
                "job_id": row.get("job_id"),
                "source": row.get("source"),
                "schema_version": row.get("schema_version"),
                "title": title.lower(),
                "title_clean": title,
                "company_name": company,
                "location": location,
                "is_remote": remote,
                "published_at_raw": created,
                "skills": skills,
                "posting_url": url,
                "ingested_at": row.get("ingested_at"),
            }
        )

    df = pd.DataFrame(flattened).drop_duplicates(subset=["job_id"], keep="first")
    report = run_silver_checks(df)
    if report.row_count == 0:
        raise RuntimeError("Silver check failed: no rows after transformation.")

    ingest_date = datetime.now(timezone.utc).date().isoformat()
    out_path = cfg.silver_root / "jobs" / f"ingest_date={ingest_date}" / "part-00001.parquet"
    write_parquet(out_path, df)

    quality_payload = {
        "stage": "silver",
        "ingest_date": ingest_date,
        "row_count": report.row_count,
        "null_title": report.null_title,
        "null_company": report.null_company,
        "duplicate_job_id": report.duplicate_job_id,
        "source_bronze_file": str(bronze_file),
        "output_file": str(out_path),
    }
    quality_file = cfg.quality_root / f"silver_quality_{ingest_date}.json"
    quality_file.parent.mkdir(parents=True, exist_ok=True)
    quality_file.write_text(json.dumps(quality_payload, indent=2), encoding="utf-8")
    return quality_payload


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
